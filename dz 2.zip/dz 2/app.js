let http = require('http');

function handler(request, response){
    if(request.method === "GET"){
        response.end("Привет Мир!");
    } else if(request.method === "POST"){
        response.end("Как дела?");
    }
}

let server = http.creatServer(handler);

server.listen(8080);